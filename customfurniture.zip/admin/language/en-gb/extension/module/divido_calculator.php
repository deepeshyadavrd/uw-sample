<?php
// Heading
$_['heading_title']    = 'Divido Product Page Calculator';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Divido Product Page Calculator!';
$_['text_edit']        = 'Edit Divido Product Page Calculator';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module Divido Product Page Calculator!';