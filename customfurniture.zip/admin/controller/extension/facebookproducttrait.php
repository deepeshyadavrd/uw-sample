<?php
// Copyright 2017-present, Facebook, Inc.
// All rights reserved.

// This source code is licensed under the license found in the
// LICENSE file in the root directory of this source tree.

// this is a dummy placeholder class retained for backward compatibility
// for existing plugin users to avoid class not available errors
// from plugin version 2.2.0 onwards, 
// this class has been shifted to system/library/facebookproducttrait.php
trait ControllerExtensionFacebookProductTrait {

}
