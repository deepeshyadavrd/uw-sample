<!DOCTYPE html>
<html lang="en">
<head>
  <title>Urbanwood-Bangalore</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<?php include 'header.php';?>
</head>


<body> 
<style>
  .textsliderhead{
    height: 25px !important;
  }
  .textsliderhead >p{
    color: #fff;
  }
#topslider-marquee {
    background: linear-gradient(1deg, black, #4b4b4b);
    text-align: center;
    color: #fff;
    animation: slide-animation 20s infinite;
    padding: 5px 0px;
    line-height: 2;
}
#topslider-marquee p{
  margin:auto !important ;   
  font-size: 16px; 
}


#topslider-marquee ul
{
	-webkit-animation: slide-animation 20s infinite;
  animation:slide-animation 20s infinite; 
  list-style: none outside none;      

}

#topslider-marquee:hover
{
	-moz-animation-play-state: paused;
	-webkit-animation-play-state: paused;
  -o-animation-play-state: paused;
  animation-play-state: paused;
}

    </style>
<div id="topslider-marquee" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item textsliderhead active">
       <p>
        “<b>Diwali sale is live</b>: Get 55% + 5% extra off on thousands of products“
       </p>
      </div>
      <div class="carousel-item textsliderhead">
        <p>
          “<b>No Cost EMI Offers</b> - Available With All Leading Banks“
         </p>
      </div>
      <div class="carousel-item textsliderhead"> 
        <p>
          “Free Dhipping on All Products Across India“
         </p> 
      </div>
    </div>

  </div>
<?php include 'menu.php';?>

  <div class="wrapper">

<div class="sidecall">
<button type="button" class=" requestcall" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight"> Request Call <span><i class='bx bx-phone-call bx-tada' ></i> </span></button>
</div> 
<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
  <div class="offcanvas-header">
    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
   <div class="modal-header text-center d-block">
        <h5 class="modal-title" id="exampleModalLabel">Request a Callback</h5>
        <p class="text-center">We will contact you as soon as we have received your information. </p>
      </div>
      <div class="modal-body">
        <form>
          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Name</label>
            <input type="text" class="form-control" id="user-name">
          </div>
          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Email Adderess</label>
            <input type="text" class="form-control" id="email-address">
          </div>
          <div class="mb-3">
            <label for="recipient-num" class="col-form-label">Contact No.</label>
            <input type="text" class="form-control" id="con-num">
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">Message:</label>
            <textarea class="form-control" id="message-text"></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer text-center">
        <button type="button" class="send-btn">Send message</button>
      </div>
  </div>
</div>
<div class="slider-outer text-white">
<!-- Carousel -->

<div class="container container-custom" style="width: 100%;">
<div class="row ">
  <div class="col-lg-3 d-lg-block d-none">
    <div class=" cp-with">    
        <img src="assets/image/bangalorestore.jpg" class="img-responsive img-fluid">
       
      </div> 
     
  </div>
<div class="col-lg-9">

<div id="demo" class="carousel slide d-none d-sm-block" data-bs-ride="carousel" >

  <!-- Indicators/dots -->
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
  </div>
  
  <!-- The slideshow/carousel -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <div class="slider-img">
      <img src="assets/image/banner-design1.jpg" alt="Los Angeles" class="d-block img-responsive img-fluid" width="100%" height="100%">
      </div>
    </div>
  <div class="carousel-item">
      <div class="slider-img">
      <img src="assets/image/winterbanner.jpg" alt="Los Angeles" class="d-block img-responsive img-fluid" width="100%" height="100%">
      </div>
    </div>
    <div class="carousel-item">
      
      <div class="slider-img">
      <img src="assets/image/winterbanner.jpg" alt="Los Angeles" class="d-block img-responsive img-fluid" width="100%" height="100%">
      </div>
    </div>
  </div>
  
  <!-- Left and right controls/icons -->
  <button class="carousel-control-prev home-slider-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next home-slider-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>
 
<div id="demo2" class="carousel slide d-block d-sm-none mt-5 pt-3" data-bs-ride="carousel">

  <!-- Indicators/dots -->
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#demo2" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#demo2" data-bs-slide-to="1"></button>
  </div>
  
  <!-- The slideshow/carousel -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <div class="slider-img">
      <img src="assets/image/mobile-banner.jpg" alt="Los Angeles" class="d-block img-fluid img-responsive">
      </div>
    </div>
  <div class="carousel-item">
      <div class="slider-img">
      <img src="assets/image/mobile-banner-design1.jpg" alt="Los Angeles" class="d-block img-fluid img-responsive">
      </div>
    </div>
   
  </div>
  
  <!-- Left and right controls/icons -->
  <button class="carousel-control-prev home-slider-control-prev" type="button" data-bs-target="#demo2" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next home-slider-control-next" type="button" data-bs-target="#demo2" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>
</div>
</div>
</div>
</div>
<!-- -slider end -->
<!-- quality section-->

<div class="qu-sec py-2">
  <div class="container container-custom">
    <div class="row"> 
    <h2 class="pg-heading text-center">
      Quality You Can Depend on 
    </h2>
    <p class="heading-para text-center ">Creating An Interior That Reflects Your Style And Energy</p>
    <div class="d-flex justify-content-md-center  m-md-auto  categories-pp">
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
  <div class="qu-box">
    <div class="_box_icon">
      <img src="assets/image/icon/ship-vector.svg" class="img-responsive img-fluid">
    </div>
    <h6 class="qu_box_heading text-center">Free Shipping</h6>

  </div>
</div>


<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
  <div class="qu-box">
    <div class="_box_icon">
      <img src="assets/image/icon/warranty-vector.svg" class="img-responsive img-fluid">
    </div>
    <h6 class="qu_box_heading text-center">Warranty Coverage</h6>
    
  </div>
</div>

<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
  <div class="qu-box">
    <div class="_box_icon">
      <img src="assets/image/icon/return-vector.svg" class="img-responsive img-fluid">
    </div>
    <h6 class="qu_box_heading text-center"> Easy Returns</h6>
   
  </div>
</div>

<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
  <div class="qu-box">
    <div class="_box_icon">
      <img src="assets/image/icon/care-vector.svg" class="img-responsive img-fluid">
    </div>
    <h6 class="qu_box_heading text-center">Dedicated Customer Care</h6>
   
  </div>
</div>
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
  <div class="qu-box">
    <div class="_box_icon">
      <img src="assets/image/icon/ph_medal-fill.png" class="img-responsive img-fluid">
    </div>
    <h6 class="qu_box_heading text-center">Best price guarantee</h6>
  
  </div>
</div>
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
  <div class="qu-box">
    <div class="_box_icon">
      <img src="assets/image/icon/tabler_wood.png" class="img-responsive img-fluid">
    </div>
    <h6 class="qu_box_heading text-center">A grade sheesham wood </h6>
  
  </div>
</div>
</div>
</div>
  </div>
</div>

<!-- end quality section-->

<!-- Popular Categories-->
<section class="popular-catagories d-flex py-2">
  <div class="container container-custom">
    <div class="row">
      <h2 class="pg-heading text-center">
      Popular Categories
    </h2>
    <p class="heading-para text-center ">Unlimited Options. Unbelievable Prices. Free Delivery</p>
</div>
<div class="row d-sm-flex d-block justify-content-center categories">
<div class="col-lg-2 col-md-3 col-sm-3 wdith-50-sm ">
  <a href="">
  <div class="pp-item-box">
    <div class="item-name">Beds <span> </span></div>
    <div class="popular-items-img"> 
    <img src="assets/image/popular-items/jollybed.jpg" class="img-responsive img-fluid">
    </div>
  </div>
  </a>
</div>


<div class="col-lg-2 col-md-3 col-sm-3 wdith-50-sm ">
  <a href="">
  <div class="pp-item-box">
    <div class="item-name">Fabric Sofa<span> </span></div>
    <img src="assets/image/popular-items/curio-fabric-sofa.jpg" class="img-responsive img-fluid">
  </div>
</a>
</div> 


<div class="col-lg-2 col-md-3 col-sm-3 wdith-50-sm ">
  <a href="">
  <div class="pp-item-box">
    <div class="item-name">Dining Table Sets <span> </span></div>
    <img src="assets/image/popular-items/marblediningset.jpg" class="img-responsive img-fluid">
  </div>
</a>
</div> 

<div class="col-lg-2 col-md-3 col-sm-3 wdith-50-sm ">
  <a href="">
  <div class="pp-item-box">
    <div class="item-name">Coffee Table <span> </span></div>
    <img src="assets/image/popular-items/coffeetable.jpg" class="img-responsive img-fluid">
  </div>
</a>
</div> 


<div class="col-lg-2 col-md-3 col-sm-3 wdith-50-sm ">
  <a href="">
  <div class="pp-item-box">
    <div class="item-name">Wooden Sofas <span> </span></div>
    <img src="assets/image/popular-items/woodensofa.jpg" class="img-responsive img-fluid">
  </div>
</a>
</div> 

<div class="col-lg-2 col-md-3 col-sm-3 wdith-50-sm ">
  <a href="">
  <div class="pp-item-box">
    <div class="item-name">TV Units <span> </span></div>
    <img src="assets/image/popular-items/tv-unit.jpg" class="img-responsive img-fluid">
  </div>
</a>
</div>


 <div class="col-lg-2 col-md-3 col-sm-3 wdith-50-sm ">
  <a href="">
  <div class="pp-item-box">
    <div class="item-name">Diwans<span> </span></div>
    <img src="assets/image/popular-items/diwan.jpg" class="img-responsive img-fluid">
  </div>
</a>
</div> 
<!-- </div>
<div class="row d-md-flex justify-content-center d-sm-flex">
 -->
<div class="col-lg-2 col-md-3 col-sm-3 wdith-50-sm ">
  <a href="">
  <div class="pp-item-box">
    <div class="item-name">Study Tables<span> </span></div>
    <img src="assets/image/popular-items/studytable.jpg" class="img-responsive img-fluid">
  </div>
</a>
</div>



<div class="col-lg-2 col-md-3 col-sm-3 wdith-50-sm ">
  <a href="">
  <div class="pp-item-box">
    <div class="item-name">Sofa Cum Beds<span> </span></div>
    <img src="assets/image/popular-items/sofacumbed.jpg" class="img-responsive img-fluid">
  </div>
</a>
</div>


<div class="col-lg-2 col-md-3 col-sm-3 wdith-50-sm ">
  <a href="">
  <div class="pp-item-box">
    <div class="item-name">Bookcases<span> </span></div>
    <img src="assets/image/popular-items/bookcase.jpg" class="img-responsive img-fluid">
  </div>
</a>
</div>


<div class="col-lg-2 col-md-3 col-sm-3 wdith-50-sm ">
  <a href="">
  <div class="pp-item-box">
    <div class="item-name">Dressing Tables <span> </span></div>
    <img src="assets/image/popular-items/dressingtable.jpg" class="img-responsive img-fluid">
  </div>
</a>
</div>


<div class="col-lg-2 col-md-3 col-sm-3 wdith-50-sm ">
  <a href="">
  <div class="pp-item-box">
    <div class="item-name">Shoe Racks<span> </span></div>
    <img src="assets/image/popular-items/shoerack.jpg" class="img-responsive img-fluid">
  </div>
</a>
</div>


    </div>
  </div>
</section>
<!-- end Popular Categories-->


<section class="call_to_action_sec  pt-3 pb-2">
  <div class="container container-custom">
    <div class="row">
      <div class="col-lg-6 col-md-12 px-lg-5">
        <div class="outer-img-show">
        <div class="imgs-show-grid img-show-1">
          <img src="assets/image/expert-call.png" class="img-responsive img-fluid">
        </div>
      </div>
      </div>
      <div class="col-lg-6 col-md-12 py-2 my-lg-5 px-lg-5 py-md-0">
         <h2 class="pg-heading text-lg-end text-center text-white">
      Talk To Our Furniture <br> Expert Now
    </h2>
    <p class="heading-para text-lg-end text-center text-white">Unlimited Options. Unbelievable Prices. Free Delivery</p>
    <ul class="list-_ul">
    <li class="call_source_button" type="button"><a href="">  <span> <img src="assets/image/icon/live_chat.svg"> </span> Live Chat </a> </li>
    <li class="call_source_button" type="button"><span> <a href="tel:+91 89496 95921"> <img src="assets/image/icon/call-icon.svg"> </a> | <a href=""> <img src="assets/image/icon/whatsapp.svg"> </a> </span> +91 89496 95921 </li>
  </ul>

      </div>
<hr class="line_hr">
<h1 class="text-center text-white pg-heading">India’s Best Quality Wooden furniture in Bangalore</h1>
<span class="text-center text-white heading-para">The Urbanwood furniture you place in your house significantly affects the look and the solace of your home. Regardless of whether you incline toward conventional wooden furniture or customized furniture <button id="show" class="show3 btn-show">Read more....</button> </span>
<span class="text-center text-white heading-para con-text" style="display: none;">
   online, it ought to be as indicated by your inclinations, accessible space and the inside of your home. While each piece of home furniture that you pick ought to be deliberately thought upon, you should give additional consideration while buying furniture online as these rooms are the essence of your house. Along these lines, while you are investigating the different furniture online Bangalore to locate the best wood furniture, search for the most recent plans just as strength for your living room furniture for Home.<button id="hide" class="hide3 btn-show" style="display:none"> Less...</button> 

</span>

    </div>
  </div>
</section>

<section class="trending_sec py-2">
<div class="container container-custom">
  <div class="row">
      <h2 class="pg-heading text-center">Top Trending Furnitures </h2>
    <p class="heading-para text-center ">We Have Everything You Need</p>
<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 wdith-50-sm">

  <div class="trending-product-box">
    <div class="product_img"> 
    <a href="">
      <span class="sale-badge">Best <br>Sale</span>
   <img src="assets/image/trending-item/img-1.jpg" class="img-responsive img-fluid">
   </a>
     </div>
     <div class="product-content">
        <div class="p_item-name"><a href="">Hydraulic Storage Beds </a></div>
       <div class="p_item-price"> 
        <p>Starting From <br> <span class="tax-text">(inclusive of all taxes) </span></p>
<h5 class="p_item-amount_"> <i class='bx bx-rupee'></i>  66,045</h5>
       </div>
     </div>
  </div>

</div>
<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 wdith-50-sm">
  <a href="">
  <div class="trending-product-box">
    <div class="product_img"> 
      <span class="sale-badge">Best <br>Sale</span>
   <img src="assets/image/trending-item/img-2.jpg" class="img-responsive img-fluid">
     </div>
     <div class="product-content">
        <div class="p_item-name"><a href="">Wardrobes</a></div>
       <div class="p_item-price"> 
        <p>Starting From <br> <span class="tax-text">(inclusive of all taxes) </span></p>
<h5 class="p_item-amount_"> <i class='bx bx-rupee'></i>  66,045</h5>
       </div>
     </div>
  </div>
</a>
</div>
<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 wdith-50-sm">
  <a href="">
  <div class="trending-product-box">
    <div class="product_img"> 
      <span class="sale-badge">Best <br>Sale</span>
   <img src="assets/image/trending-item/img-3.jpg" class="img-responsive img-fluid">
     </div>
     <div class="product-content">
        <div class="p_item-name"><a href="">Chest of Drawers </a></div>
       <div class="p_item-price"> 
        <p>Starting From <br> <span class="tax-text">(inclusive of all taxes) </span></p>
<h5 class="p_item-amount_"> <i class='bx bx-rupee'></i>  66,045</h5>
       </div>
     </div>
  </div>
</a>
</div>
<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 wdith-50-sm">
  <a href="">
  <div class="trending-product-box">
    <div class="product_img"> 
      <span class="sale-badge">Best <br>Sale</span>
   <img src="assets/image/trending-item/img-4.jpg" class="img-responsive img-fluid">
     </div>
     <div class="product-content">
        <div class="p_item-name"><a href="">Loveseats</a></div>
       <div class="p_item-price"> 
        <p>Starting From <br> <span class="tax-text">(inclusive of all taxes) </span></p>
<h5 class="p_item-amount_"> <i class='bx bx-rupee'></i>  66,045</h5>
       </div>
     </div>
  </div>
</a>
</div>
  </div>
</div>
</section>

<section class="shop_by_room">
  <div class="container container-custom">
    <div class="row">
      <h2 class="pg-heading text-center">Shop by Room's</h2>
    <p class="heading-para text-center ">Any Room, Any Size, Any Furniture, Just Come To Us</p>  


    </div>
  </div>
  
<div class="trends">
    <div class="bbb_background"></div>
    <div class="bbb_overlay"></div>
    <div class="container container-custom">
        <div class="row">
            <div class="col-lg-4">
                <div class="bbb_container">
                    <h2 class="bbb_title pg-heading">Living Room Furniture</h2>
                    <div class="bbb_text ">
                        <p class="heading-para">Living room furnishings effectively round off the interior design
of the house.When considering how to decorate a home, it is the
first idea that everyone has.</p>
<p class="global-price-amount">Starting From  <b> ₹ 5,990 </b></p>
<a href="" type="button" class="view_all_btn"> View all</a>
                    </div>
                    
                </div>
            </div>
            <div class="col-lg-8">
                <div class="bbb_slider_container">
                  <div class="bbb_slider_nav">
                        <div class="bbb_prev1 bbb_nav"><i class='bx bx-chevron-left' ></i></div>
                        <div class="bbb_next1 bbb_nav"><i class='bx bx-chevron-right'></i></div>
                    </div>
                    <div class="owl-carousel owl-theme bbb_slider bbb-slider1">

                        <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/livingroom/img-1.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">Fabric Sofas</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>

                        <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/livingroom/img-2.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">TV Units</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>

                        <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/livingroom/img-3.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">Sideboards</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>

                        <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/livingroom/img-4.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">Console Tables</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>
                        <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/livingroom/img-5.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">Wall Shelves</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>
                        <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/livingroom/img-6.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">Coffee Tables</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>
                     
                    </div>
                </div>

            </div>
        </div>
        <hr class="line_hr">
    </div>
    <!--- second carousel--->
       <div class="container container-custom">
        <div class="row flex-lg-row-reverse ">
            <div class="col-lg-4">
                <div class="bbb_container">
                    <h2 class="bbb_title pg-heading text-lg-end">BedRoom Furniture</h2>
                    <div class="bbb_text text-lg-end">
                        <p class="heading-para">Making your bedroom feel like home requires a personal touch. Everything you need to feel peaceful and at home in your personal area may be found here.</p>
<p class="global-price-amount">Starting From  <b> ₹ 5,990 </b></p>
<a href="" type="button" class="view_all_btn"> View all</a>
                    </div>
                    
                </div>
            </div>
            <div class="col-lg-8">
                <div class="bbb_slider_container">
                  <div class="bbb_slider_nav">
                        <div class="bbb_prev2 bbb_nav"><i class='bx bx-chevron-left' ></i></div>
                        <div class="bbb_next2 bbb_nav"><i class='bx bx-chevron-right'></i></div>
                    </div>
                    <div class="owl-carousel  owl-theme bbb_slider bbb_slider2">

                        <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/bedroom/img1.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">Canvas</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>

                        <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/bedroom/img2.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">Wordrobes</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>

                        <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/bedroom/img3.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">Chest of Drawers</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>

                        <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/bedroom/img4.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">Bedside Tables</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>

                          <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/bedroom/img5.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">Dressing Tables</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>


                          <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/bedroom/img6.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">Nested Tables </a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>
                     
                    </div>
                </div>

            </div>
        </div>
        <hr class="line_hr">
    </div>
<!--- third carousel--->
   <div class="container container-custom">
        <div class="row">
            <div class="col-lg-4">
                <div class="bbb_container">
                    <h2 class="bbb_title pg-heading ">Dining Room Furniture</h2>
                    <div class="bbb_text">
                        <p class="heading-para">The dining room is a place where families spend quality time together. Therefore, dining room furniture should always be lively and interesting. Get the perfect dining room furniture right here.</p>
<p class="global-price-amount">Starting From  <b> ₹ 5,990 </b></p>
<a href="" type="button" class="view_all_btn"> View all</a>
                    </div>
                    
                </div>
            </div>
            <div class="col-lg-8">
                <div class="bbb_slider_container">
                  <div class="bbb_slider_nav">
                        <div class="bbb_prev3 bbb_nav"><i class='bx bx-chevron-left' ></i></div>
                        <div class="bbb_next3 bbb_nav"><i class='bx bx-chevron-right'></i></div>
                    </div>
                    <div class="owl-carousel owl-theme bbb_slider bbb_slider3">

                        <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/diningroom/img-1.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">6 Seater Table Sets</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>

                        <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/diningroom/img-2.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">Round Dining Table Sets</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>

                        <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/diningroom/img-3.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">Dining Tables</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>

                        <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/diningroom/img-4.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">Dining Chairs</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>
                         <div class="owl-item">
                            <div class="bbb_item is_new">
                                <div class="bbb_image d-flex flex-column align-items-center justify-content-center">
                                  <img src="assets/image/shopbyrom/diningroom/img-5.jpg" alt=""></div>
                                <div class="bbb_content">
                                      <div class="bbb_name"><a href="#">Bar Cabinets</a></div>
                                   
                                    <div class="bbb_info clearfix">
                                     <div class="bbb_category"><a href="#"> 25+ Options | Starting From</a></div>
                                        <div class="bbb_price">₹13790</div>
                                    </div>
                                </div>
                                <ul class="bbb_marks">
                                    <li class="bbb_mark bbb_discount">-25%</li>
                                    <li class="bbb_mark bbb_new">new</li>
                                </ul>
                                <div class="bbb_fav"><i class='bx bx-heart' ></i></div>
                            </div>
                        </div>
                     
                    </div>
                </div>

            </div>
        </div>
      
    </div>

</div>
</section>
<!-- sale banner -->
<!-- <section class="py-2">
      <div class="container container-custom">
        <div class="row">
          <img src="assets/image/salebanner.jpg" class="img-responsive img-fluid">
        </div>
      </div>
</section> -->
<!-- end sale banner -->

<section class="custom py-2">
<div class="container container-custom">
<div class="row">
<div class="col-lg-6 col-md-6">
  <div class="bg-custom">
    <h2 class="pg-heading text-lg-start text-center text-white"> <span> Product Customization </span> <br>
      SIZE, COLOR, DESIGN
    </h2>
    <p class="heading-para text-lg-start text-center text-white"> Got a dream furniture in mind we will make it for you</p>
    <button type="button" class="custom_btn">Customizes now</button>
  </div>
</div>
<div class="col-lg-6 col-md-6">
  <div>
    <img src="assets/image/sofa-man.png" class="img-fluid img-responsive">
  </div>
</div>
</div>
</div>
</section>


<!-- Top Selling Product section -->

<section class="py-2 most_popular_sec">
  <div class="container container-custom">
    <div class="row">
      <div class="d-flex justify-content-between align-items-center">
        <div> 
          <h2 class="pg-heading text-lg-start text-start">Top Selling Product</h2>
    <p class="heading-para text-lg-start text-start">Awe-Inspiring Bed Designs</p>
    
     </div>
        <a href="" type="button" class="view_all_btn float-right-btn"> View all</a>
      </div>
   
 <div class="bbb_slider_container">
                  <!-- <div class="bbb_slider_nav">
                        <div class="bbb_prev4 bbb_nav"><i class='bx bx-chevron-left' ></i></div>
                        <div class="bbb_next4 bbb_nav"><i class='bx bx-chevron-right'></i></div>
                    </div> -->
                    <div class="owl-carousel owl-theme bbb_slider bbb_slider4">

                        <div class="owl-item owl-item4">
                            <div class="bbb_item bbb_item4 is_new">
                               
        <div class="pp2-item-box">
          <div class="item-img">
            <img src="assets/image/popular-sofa/img-8.jpg" class="img-responsive img-fluid" alt="">
          </div>
          <div class=""><a href="https://www.urbanwood.in/relay-ceramic-tile-diwan-walnut-finish"  class="d-block pp-name-title"> Relay Ceramic Tile Diwan</a></div>
          <div class="item-content">
            <div class="pp-name"> 
               <p> Starting from  <span>(Including of all Taxes)</span></p>
            </div>
            <div class="_pp_content clearfix">
            <div class="pp-price">
             
              <h6>₹53,419</h6>
            </div>
            </div>
          </div>
          <span class="off_badge">
            50% <br>OFF
          </span>
        </div>
    
                            </div>
                        </div>
<div class="owl-item owl-item4">
                            <div class="bbb_item bbb_item4 is_new">
                               
        <div class="pp2-item-box">
          <div class="item-img">
          <img src="assets/image/popular-sofa/img-9.jpg" class="img-responsive img-fluid" alt="">
          </div>
          <div class=""><a href="https://www.urbanwood.in/selin-shoe-rack-honey-finish" class="d-block pp-name-title">Selin Shoe Rack</a></div>
          <div class="item-content">
            <div class="pp-name"> 
               <p> Starting from  <span>(Including of all Taxes)</span></p>
            </div>
            <div class="_pp_content clearfix">
            <div class="pp-price">
             
              <h6>₹53,419</h6>
            </div>
            </div>
          </div>
          <span class="off_badge">
            50% <br>OFF
          </span>
        </div>
     
                            </div>
                        </div>


                        <div class="owl-item owl-item4">
                            <div class="bbb_item bbb_item4 is_new">
                                
        <div class="pp2-item-box">
          <div class="item-img">
          <img src="assets/image/popular-sofa/img-10.jpg" class="img-responsive img-fluid" alt="">
          </div>
          <div class=""> <a href="https://www.urbanwood.in/bliss-coffee-table-teak-finish" class="d-block pp-name-title">Bliss Coffee Table</a></div>
          <div class="item-content">
            <div class="pp-name">
               <p> Starting from  <span>(Including of all Taxes)</span></p>
            </div>
            <div class="_pp_content clearfix">
            <div class="pp-price">
             
              <h6>₹53,419</h6>
            </div>
            </div>
          </div>
          <span class="off_badge">
            50% <br>OFF
          </span>
        </div>
 
                            </div>
                        </div>


                        <div class="owl-item owl-item4">
                            <div class="bbb_item bbb_item4 is_new">
                                 
        <div class="pp2-item-box">
          <div class="item-img">
          <img src="assets/image/popular-sofa/img-8.jpg" class="img-responsive img-fluid" alt="">
          </div>
          <div class=""> <a href="https://www.urbanwood.in/monarch-lounge-chair-velvet-sapphire-blue" class="d-block pp-name-title">Monarch Lounge Chair</a></div>

          <div class="item-content">
            <div class="pp-name"> 
               <p> Starting from  <span>(Including of all Taxes)</span></p>
            </div>
            <div class="_pp_content clearfix">
            <div class="pp-price">
             
              <h6>₹53,419</h6>
            </div>
            </div>
          </div>
          <span class="off_badge">
            50% <br>OFF
          </span>
        </div>
              </div>
                        </div>

                        <div class="owl-item owl-item4">
                            <div class="bbb_item bbb_item4 is_new">
                                 
        <div class="pp2-item-box">
          <div class="item-img">
          <img src="assets/image/popular-sofa/img-8.jpg" class="img-responsive img-fluid" alt="">
          </div>
          <div class=""> <a href="https://www.urbanwood.in/trace-bed-without-storage-king-size-honey-finish?search=trace" class="d-block pp-name-title">Trace Bed Without Storage</a></div>
          <div class="item-content">
            <div class="pp-name">
               <p> Starting from  <span>(Including of all Taxes)</span></p>
            </div>
            <div class="_pp_content clearfix">
            <div class="pp-price">
             
              <h6>₹53,419</h6>
            </div>
            </div>
          </div>
          <span class="off_badge">
            50% <br>OFF
          </span>
        </div>
    
                            </div>
                        </div>

                         <div class="owl-item owl-item4">
                            <div class="bbb_item bbb_item4 is_new">
                                 
        <div class="pp2-item-box">
          <div class="item-img">
          <img src="assets/image/popular-sofa/img-8.jpg" class="img-responsive img-fluid" alt="">
          </div>
          <div class=""> <a href="https://www.urbanwood.in/aiden-sofa-cum-bed-honey-finish" class="d-block pp-name-title">Aiden Sofa Cum Bed</a></div>
          <div class="item-content">
            <div class="pp-name">
               <p> Starting from  <span>(Including of all Taxes)</span></p>
            </div>
            <div class="_pp_content clearfix">
            <div class="pp-price">
             
              <h6>₹53,419</h6>
            </div>
            </div>
          </div>
          <span class="off_badge">
            50% <br>OFF
          </span>
        </div>
    
                            </div>
                        </div>

                         <div class="owl-item owl-item4">
                            <div class="bbb_item bbb_item4 is_new">
                                 
        <div class="pp2-item-box">
          <div class="item-img">
          <img src="assets/image/popular-sofa/img-8.jpg" class="img-responsive img-fluid" alt="">
          </div>
          <div class=""> <a href="https://www.urbanwood.in/beck-l-shaped-left-aligned-sofa-velvet-stone-grey" class="d-block pp-name-title"> Beck L-Shaped Left Aligned Sofa</a></div>
          <div class="item-content">
            <div class="pp-name">
               <p> Starting from  <span>(Including of all Taxes)</span></p>
            </div>
            <div class="_pp_content clearfix">
            <div class="pp-price">
             
              <h6>₹53,419</h6>
            </div>
            </div>
          </div>
          <span class="off_badge">
            50% <br>OFF
          </span>
        </div>
    
                            </div>
                        </div>

                     
                    </div>
                </div>
      

    </div>
  </div>
</section>

<section class="py-2">
  <div class="container container-custom">
    <div class="row">
      <div class="col-lg-6">
        <div class="pp-on-sale">
          <span class="onsale_badge"> On Sale</span>
          <img src="assets/image/bed-img.png" class="img-responsive img-fluid">
        </div>
      </div>
      <div class="col-lg-6">
 <h2 class="pg-heading text-lg-start">Solid Wood Poster Beds</h2>
    <p class="heading-para text-lg-start ">Purchase solid Sheesham wood poster beds in India. Available in all sizes (King and Queen) and with various storage options, including top opening storage, drawer storage, and regulars</p>
    <div class="price-sec">
      <div class="offer-text">OFFER PRICE <br> <span> (Inclusive all of taxes)</span></div>
      <div class="cost-sec"> 
     <div class="amount">₹57,350 <span class="text-cut"> ₹139,099 </span> <span class="off_badge2"> 50% OFF</span></div>
      </div>
    </div>

    <ul class="qa-list">

      <li><i class='bx bx-check'></i> <span> Made in Solid Sheesham Wood. </span> </li>
      <li> <i class='bx bx-check'></i> <span> The unique texture of this lovable poster bed looks very classy when polished. </span> </li>
      <li><i class='bx bx-check'></i> <span> 1 Year Warranty & Free Delivery All India. </span></li>
    </ul>
    <a href="" type="button" class="view_all_btn mt-5 "> View all</a>
      </div>
    </div>
  </div>
</section>

<section class="store_branch py-2">
  <div class="container container-custom">
    <div class="row">
      <h2 class="pg-heading text-center">Urbanwood Stores & Studios</h2>
    <p class="heading-para text-center">Offline Furniture Experience Store</p>
    </div>
  </div>
  <div class="container container-custom">
  <div class="row">
    <div class="MultiCarousel" data-items="1,3,5,6" data-slide="1" id="MultiCarousel"  data-interval="1000">
            <div class="MultiCarousel-inner">
                <div class="item">
                    <div class="pad15">
                      <a href="">
                      <img src="assets/image/banglore-branch.jpg" class="img-responsive img-fluid">
                        <p class="lead">Bangalore</p>
                       </a>
                    </div>
                </div>
                <div class="item">
                    <div class="pad15">
                      <a href="">
                      <img src="assets/image/mumbai-branch.jpg" class="img-responsive img-fluid">
                        <p class="lead">Mumbai</p>
                       </a>
                    </div>
                </div>
                
                <div class="item">
                    <div class="pad15">
                      <a href="">
                      <img src="assets/image/chenai-branch.jpg" class="img-responsive img-fluid">
                        <p class="lead">Chennai</p>
                       </a>
                    </div>
                </div>

                <div class="item">
                    <div class="pad15">
                      <a href="">
                      <img src="assets/image/baranch1.jpg" class="img-responsive img-fluid">
                        <p class="lead">Jaipur</p>
                       </a>
                    </div>
                </div>

                <div class="item">
                    <div class="pad15">
                      <a href="">
                      <img src="assets/image/gurgaon-branch.jpg" class="img-responsive img-fluid">
                        <p class="lead">Gurugram</p>
                       </a>
                    </div>
                </div>
                
            </div>
            <button class="btn btn-light leftLst"><i class='bx bx-chevron-left' ></i></button>
            <button class="btn btn-light rightLst"><i class='bx bx-chevron-right'></i></button>
        </div>
  </div>
 
  </div>

  <div class="container container-custom py-lg-2 mt-lg-2">
  <div class="row"> 
<div class="col-lg-3 col-md-12 ">
   <h2 class="pg-heading text-lg-start text-center mt-lg-5">Customer Stories</h2>
    <p class="heading-para text-lg-start text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse </p>
    <a href="" type="button" class="view_all_btn mt-lg-3 mt-md-2"> View all</a>
</div>
<div class="col-lg-9 col-md-12">
   <section class="customer-logos slider">
      <div class="slide client-box"> 
      
       <div class="client-img">
         <img src="assets/image/review-img-test.jpg" class="img-responsive img-fluid ">
       </div>
<div class="client-content">
  <div class="client-name"> <p> Sneha tn <span>( Bangalore ) </span> </p></div>
  <div class="client-comment">
<p>Needed custom coffee table to match my pouffes . They did an excellent job in designing to my requirements and delivering on time , with very good quality finish and packaging</p>
<div class="rating">
  <span><i class='bx bxs-star'></i></span>
  <span><i class='bx bxs-star'></i></span>
  <span><i class='bx bxs-star'></i></span>
  <span><i class='bx bxs-star'></i></span>
  <span><i class='bx bxs-star'></i></span>
</div>
<a href="" type="button" class="see-product-btn">See product</a>
   </div>
</div>

    </div>

      <div class="slide client-box"> 
       <div class="client-img">
         <img src="assets/image/review-img/client-1-img.png" class="img-responsive img-fluid ">
       </div>
<div class="client-content">
  <div class="client-name"> <p> Sneha tn <span>( Bangalore ) </span> </p></div>
  <div class="client-comment">
<p>When we think about comfort after a long hectic day we usually lay down on our beds for relaxation this
   bed which I got from URBAN WOOD is very elegant and satisfying in design and strength,
   design can give you eye satisfaction and strength can give my kids enjoy at there fullest.</p>
<div class="rating">
  <span><i class='bx bxs-star'></i></span>
  <span><i class='bx bxs-star'></i></span>
  <span><i class='bx bxs-star'></i></span>
  <span><i class='bx bxs-star'></i></span>
  <span><i class='bx bxs-star'></i></span>
</div>
<a href="" type="button" class="see-product-btn">See product</a>
   </div>
</div>
      </div>

      <div class="slide client-box"> 
       <div class="client-img">
         <img src="assets/image/review-img/client-1-img.png" class="img-responsive img-fluid ">
       </div>
<div class="client-content">
  <div class="client-name"> <p> Sneha tn <span>( Bangalore ) </span> </p></div>
  <div class="client-comment">
<p>Needed custom coffee table to match my pouffes . They did an excellent job in designing to my requirements and delivering on time , 
  with very good quality finish and packaging   with very good quality finish and packaging  with very good quality finish and packaging</p>
<div class="rating">
  <span><i class='bx bxs-star'></i></span>
  <span><i class='bx bxs-star'></i></span>
  <span><i class='bx bxs-star'></i></span>
  <span><i class='bx bxs-star'></i></span>
  <span><i class='bx bxs-star'></i></span>
</div>
<a href="" type="button" class="see-product-btn">See product</a>
   </div>
</div>
      </div>

   </section>
</div>
  </div>

</div>
</section>

<section class="insta-sec pt-lg-1 pb-lg-5 py-md-5">
  <div class="container container-custom">
    <div class="row">
      <div class="col-lg-6">
        <h2 class="pg-heading text-lg-start text-center mt-lg-5"><span class="" style="font-weight:200;">Follow us</span> on Instagram</h2>
        <a href="https://www.instagram.com/urbanwood.in/?next=%2F#" target="_blank"class="link_text text-lg-start text-center d-block display-6"><img src="assets/image/icon/insta-s.svg" class="img-responsive img-fluid ins-svg" style="width: 5%;"> -urbanwood#</a>
<a href="https://www.instagram.com/p/CkfFvDBvmvu/?utm_source=ig_web_copy_link" target="_blank">
<div class="insta-image">
 <img src="assets/image/instagram/image-1.png" class="img-responsive img-fluid">
  <span class=""><img src="assets/image/icon/insta-s.svg" class="img-responsive img-fluid ins-svg" width="50%"></span>
</div>
</a>

      </div>
      <div class="col-lg-6">
        <div class="row">
        <div class="col-lg-6 col-md-6">
          <a href="https://www.instagram.com/p/Ck7fA1DPdIx/?utm_source=ig_web_copy_link" target="_blank">
          <div class="insta-image in-img-box1">
 <img src="assets/image/instagram/image-2.png" class="img-responsive img-fluid">
  <span class=""><img src="assets/image/icon/insta-s.svg" class="img-responsive img-fluid ins-svg" width="50%"></span>
</div>
</a>
        </div>
        <div class="col-lg-6 col-md-6">
           <a href="https://www.instagram.com/p/ClSqR1EvgQH/?utm_source=ig_web_copy_link" target="_blank">
          <div class="insta-image in-img-box2">
 <img src="assets/image/instagram/image-3.png" class="img-responsive img-fluid">
   <span class=""><img src="assets/image/icon/insta-s.svg" class="img-responsive img-fluid ins-svg" width="50%"></span>
</div>
</a>
        </div>
        <div class="col-lg-6 col-md-6">
          <a href="https://www.instagram.com/p/CkSMSp7IUHc/?utm_source=ig_web_copy_link" target="_blank">
          <div class="insta-image in-img-box3">
 <img src="assets/image/instagram/image-4.png" class="img-responsive img-fluid">
  <span class=""><img src="assets/image/icon/insta-s.svg" class="img-responsive img-fluid ins-svg" width="50%"></span>
</div>
</a>
        </div>
        <div class="col-lg-6 col-md-6">
          <a href="https://www.instagram.com/p/CjpMmX6pyCw/?utm_source=ig_web_copy_link" target="_blank">
          <div class="insta-image in-img-box4">
 <img src="assets/image/instagram/image-5.png" class="img-responsive img-fluid">
  <span class=""><img src="assets/image/icon/insta-s.svg" class="img-responsive img-fluid ins-svg" width="50%"></span>
</div>
</a>
        </div>
        </div>
      </div>
    </div>
  </div>
  </section>

  <section class="faq_sec py-lg-5 "> 
<div class="container container-custom">
  <div class="row">
    
    <div class="col-lg-6">
      <div class="accordion" id="accordionExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingOne">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        Which are the best furniture shops in Bangalore ?
      </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
      <div class="accordion-body">
       There are many furniture shops in Bangalore. But if you ask me, UrbanWood is the best of all in terms of prices, quality, and delivery.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
       Where do you buy custom furniture in Bangalore?
      </button>
    </h2>
    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        Custom furniture is in demand in this era. Everybody wants to customize furniture as per their needs be it space or number of people. If you also want the same, you can get your furniture customized from any good store in Bangalore. You can also try hands-on UrbanWood.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
       How do I buy furniture in Bangalore?
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        You can visit furniture markets in Bangalore. They can help you make choices as per your conscience.
      </div>
    </div>
  </div>
<div class="accordion-item">
    <h2 class="accordion-header" id="headingFour">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
        Accordion Item #4
      </button>
    </h2>
    <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
      </div>
    </div>
  </div>


 
</div>
    </div>

    <div class="col-lg-6">
      <div class="query-sec">
        <div> 
        <h2 class="pg-heading text-lg-start text-white"><span class="" style="font-weight: 200;">Questions? </span>  <span style="color:#fcff00"> Look here! </span></h2>
        <p class="heading-para text-lg-start text-white"> <b>Can't Find Question? </b></p>
        <div class="con-info">
          <div class="icon-2"><img src="assets/image/icon/phone-icon.png" class="img-responsive img-fluid"> </div>
          <div class="con-detail"><p class="text-white"><small > contact us for any query</small></p> <h5>  +91- 7737966778 </h5></div>
        </div>
        <div class="con-info">
          <div class="icon-2"><img src="assets/image/icon/mail-icon.png" class="img-responsive img-fluid"> </div>
          <div class="con-detail"><p class="text-white"><small > Email us for frequent response</small></p> <h5>Support@Urbanwood.In</h5></div>
        </div>
       </div>
       <div class="query_man"> 
     
      <div class=""> <img src="assets/image/query-man.png" class="img-responsive img-fluid"> </div>
       </div>
      </div>
    </div>
  </div>
</div>
  </section>
<section class="bottom-content py-4"> 
<div class="container container-custom"> 
<div class="row">
  <div class="col-lg-12">
    <button id="show2" class="show2 btn-show">Read more....</button>
<button id="hide2" class="hide2 btn-show" style="display:none"> Less...</button>
   <h5>Buy Wooden Furniture (फर्नीचर) Online in Bangalore For Your Dream Home</h5> 
<p> mbellishing Your Office Space at Home With Urbanwood. In the event that you have your workspace at your home, the <stong> office furniture </stong> ought to be amazing as well. It very well may be the conventional sort with work area and seat or like modern furniture with rocker, couches and <a href="https://www.urbanwood.in/sofas"> sofas </a>. Further, numerous <stong>modern furniture stores </stong> likewise sell foldable furniture, called <stong> modular furniture </stong>. You can look at them as well at furniture online Bangalore.</p>

<div class="con-text"style="display: none;">
  <h5> Search For Home furniture Online Bangalore For Different Looks & Designs</h5>
<p>The early introduction of your home is a ton relied upon the furniture you have in your home. In the event that your furniture is decrepit and broken, it would debase the magnificence of your home, regardless of how gigantic your house is or how vivid are the paints on the wall. Rather you can look for stylish at Urbanwood. You can either search for a stylish and smart look with furniture like arm chairs and couches or give it a conventional vibe with the texture of wooden sofas and rugs and carpets. Then again, you can likewise try different things with the various plans of <a href="https://www.urbanwood.in/tv-units"> tv units </a> and <a href="https://www.urbanwood.in/dining-tables">dining tables </a> to give it a modern look.</p>
<h5>India's Best Online Furniture Shop in Bangalore: Check Furniture Ranges at Urbanwood</h5>

<p>Urbanwood has a wide scope of home furniture <a href="https://www.urbanwood.in/l-shaped-sofas"> l shaped sofas </a>, Dining table, <strong> Cupboards, Dressing table </strong>, <a href="https://www.urbanwood.in/study-room-furniture"> study room furniture </a>, <strong> mattresses and wall paintings </strong>. Our furnitures is a comprehensive inventory of what you would in our stores. You could say that our online furniture store in Bangalore is an unobtrusive impression of the reach that we have in our <a href="https://www.urbanwood.in/online-furniture-store"> online furniture store </a>. Every class ventures into a sub-classification assisting you with picking among the different models and plans accessible. We have multi-purpose wooden furniture and all the most recent styles and plans.</p>

<p> <a href="https://www.urbanwood.in/bedroom-furniture"> <strong> Bedroom Furniture: </strong></a> A spot to return home and crash following a difficult day. Settle on the most ideal selection of wooden beds to cause you to feel loose and comfortable.</p>
<p> <a href="https://www.urbanwood.in/fabric-sofas"> <strong> Fabric Sofas: </strong></a>A Sofa is the most pursued spot at home, where everybody likes to crash in the wake of a difficult day's worth of effort so it should a comfortable spot to crash. Your sofa set would discuss your style to visitors that you engage and furthermore give solace to those family parties. Idiosyncratic or tasteful what's your decision. Buy sofas online from our wide scope of premium contributions at furniture online Bangalore.
 </p>

<p><a href="https://www.urbanwood.in/wardrobes"><strong>Wardrobes:</strong> </a>An exceptionally planned wardrobe can possibly raise the style of generally basic bedroom furniture. Urbanwood presents to you a one of a kind assortment of almirahs. A decent wardrobe ought to permit you to store and arrange your own things as per your comfort. At our furniture present to you a collection of wardrobes that are customized for differed capacity needs. Pick a wardrobe that is in a state of harmony with the style of your room just as obliges all the capacity and practical necessities.</p>

<p><a href="https://www.urbanwood.in/dining-room-furniture"> <strong> Dining room furniture:  </strong></a>A dining table is a place of food, fun, and discussions. From showing your cooking abilities to holding over food and recollections, where household work completes, investigate the enormous assortment of wooden dining tables and pick the one that is ideal for your family. Investigate the new scope of dining sets for your dining region and ensure you pick the best arrangement for your family to appreciate an incredible supper consistently. Get an individual dining table and pick your own dining chairs or go for a complete set, we have it both.</p>

<p><strong> Study and Office:</strong> For our home office and different purposes, a <a href="https://www.urbanwood.in/study-table-online">study table online </a> can be valuable and can help you work gainfully. Study tables have now become an essential need for homes. A decent table makes the errand of perusing and composing significantly more comfortable, so let the inventive brain in you be more profitable.</p>

<p><a href="https://www.urbanwood.in/D%C3%A9cor"> <strong >Decor: </strong></a>  Gone are the days where individuals favoured a plain wall with paint or only a couple of photograph edges to make it look outwardly great. Today individuals are continually searching for something new and imaginative that can get their walls decorated. With the assistance of <strong> wall hangings, wall paintings, wall arts </strong>, and gorgeously created mirrors, your wall won't ever look plain. You may get the best furniture online Bangalore that will change the appearance of your home, yet in the event that you overlook to decorate your walls, at that point you may lose the equilibrium. You may even paint the walls with a stylish tone, however, without wall decors, your wall will, in any case, continue as before. There's no motivation behind why your utility room or clothing space can't coordinate the polish of the remainder of rooms. Come look at the assortment of utility stylistic layout things just made for your home.</p>
<p><a href="https://www.urbanwood.in/Coffee-Tables"><strong>Coffee Tables:</strong> </a>  Look over the most recent <strong> wooden centre table for living room  </strong> at the best costs. The coffee table is probably going to be one of the normal furniture tables in any house. It is the point of convergence of your living room, which is encircled by originator sofa sets. No living room is finished without a coffee table that visitors and guests will see when they show up in your living room. It is the thing that gets the attention of everybody first; in this manner, it ought to be picked with the most extreme consideration from the furniture. Discover a totally modern, straightforward and exquisite focal point that will finish the vibe of your living room. Make a mark look in your living room with beautiful Coffee and end tables from Urbanwood. Shop furniture online in Bangalore at Urbanwood or shop in stores across Bangalore. In each home, the coffee table offers a new territory where you can share drinks and games with friends and family and visitors. Investigate coffee and end table sets with mathematical components and a straightforward allure.</p>
<p>Choose Different Looks Furniture for Each Room</p>
<p>You can give an alternate search for every one of your rooms in the house. For instance, the furniture utilized in your living room ought to be wonderful, exquisite just as the originator. Regardless of whether it is a sofa set or an originator plan of conventional furniture, it should upgrade the search for your living room. Essentially, your bedroom furniture ought to be comfortable, durable just as strong. It should very much fit inside the accessible space in your room without jumbling or clogging it. The furniture should coordinate the general subject of your house, which could be grave or peculiar.</p>
<p>Further, for a modern look, you can utilize a modular kitchen that embellishes the house right away. Urbanwood offers a wide scope of furniture plans to assist you with getting the best pick. You can likewise try different things with various materials for each room separately for furniture online Bangalore. For instance, you can utilize <a href="https://www.urbanwood.in/sheesham-wood-furniture"> Sheesham wood furniture </a> for your living room and utilize a wooden bed in the bedroom. At Urbanwood you can likewise investigate outdoor furniture like <a href="https://www.urbanwood.in/hanging-chairs"> hanging chairs, ottomans and pouffes </a>, <a href="https://www.urbanwood.in/bean-bags"> bean bags</a>, etc. to have a private space for yourself.</p>
<p> Urbanwood furniture in Bangalore</p>

<p> The best thing about buying furniture online is, you can get the best arrangements for furniture sale, all-round the year. While investigating furniture available to be purchased with Urbanwood, you can get the best furniture online Bangalore for your home at a profoundly limited cost with alluring looks and solidness. With Urbanwood, you can likewise get diverse furniture pieces as an unconditional present with your purchases. While buying furniture, you can utilize various channels to limit your choices. At Urbanwood, you can utilize channels like material, value, shading, markdown, class, and so on to pick the furniture that best suits your need and taste. While it would make your shopping simpler, it would likewise help you save time and endeavours.</p>

<p>The Leading Online Furniture Store Serving All Over India
Urbanwood has a wide range of home furniture to accentuate the beauty and elegance of your house. Buy <strong> furniture online in Bangalore, Hyderabad, Jaipur, Pune, Mumbai, Delhi </strong> and various other major cities of India including </p>
<p> Find the most stylish & luxury furniture sofas, beds, wardrobes, study tables and coffee tables made from high-quality Sheesham wood at Urbanwood. Stay comfortable and classy with our modern and amazing furniture for your home at competitive prices. Complete your home interiors with the best wooden furniture of your choice. Urbanwood offers a wide range of <strong> customized wooden furniture </strong> to match your interiors and styles.</p>
<p><strong> Urbanwood </strong> offers all kinds of luxury and affordable wooden furniture for your home and office made with top-notch quality materials with a vast collection to choose from. </p>
</div>  
</div>
</div>
</div>


</section>
<?php include 'footer.php';?>
</body>
</html>
