

const menu = document.querySelector(".menu");
const menuMain = menu.querySelector(".menu-main");
const goBack = menu.querySelector(".go-back");
const menuTrigger = document.querySelector(".mobile-menu-trigger");
const closeMenu = menu.querySelector(".mobile-menu-close");
let subMenu;
menuMain.addEventListener("click", (e) =>{
    if(!menu.classList.contains("active")){
        return;
    }
  if(e.target.closest(".menu-item-has-children")){
       const hasChildren = e.target.closest(".menu-item-has-children");
     showSubMenu(hasChildren);
  }
});
goBack.addEventListener("click",() =>{
     hideSubMenu();
})
menuTrigger.addEventListener("click",() =>{
     toggleMenu();
})
closeMenu.addEventListener("click",() =>{
     toggleMenu();
})
document.querySelector(".menu-overlay").addEventListener("click",() =>{
    toggleMenu();
})
function toggleMenu(){
    menu.classList.toggle("active");
    document.querySelector(".menu-overlay").classList.toggle("active");
}
function showSubMenu(hasChildren){
   subMenu = hasChildren.querySelector(".sub-menu");
   subMenu.classList.add("active");
   subMenu.style.animation = "slideLeft 0.5s ease forwards";
   const menuTitle = hasChildren.querySelector("i").parentNode.childNodes[0].textContent;
   menu.querySelector(".current-menu-title").innerHTML=menuTitle;
   menu.querySelector(".mobile-menu-head").classList.add("active");
}

function  hideSubMenu(){  
   subMenu.style.animation = "slideRight 0.5s ease forwards";
   setTimeout(() =>{
      subMenu.classList.remove("active");	
   },300); 
   menu.querySelector(".current-menu-title").innerHTML='<a href="#"><img src="assets/image/urbanwoodlogo3.png"></a>';
   menu.querySelector(".mobile-menu-head").classList.remove("active");
}

window.onresize = function(){
    if(this.innerWidth >991){
        if(menu.classList.contains("active")){
            toggleMenu();
        }

    }
}

$(function () {
    "use strict";
    
    function uncheckBox() {
      var isChecked = $("#open-search").prop("checked");
      if (isChecked) {
        $("#open-search").prop("checked", false);
      }
    }
    
    $("body").on("click", function () {
      uncheckBox();
    });
    
    $("#open-search,label").on("click", function (e) {
      e.stopPropagation();
    });
  });
    

// function notifyMe() {
//     if (!window.Notification) {
//         console.log('Browser does not support notifications.');
//     } else {
//         // check if permission is already granted
//         if (Notification.permission === 'granted') {
//             // show notification here
//             navigator.serviceWorker.register('assets/js/sw.js');
//             navigator.serviceWorker.ready.then(function(registration) {
//                 registration.showNotification('Notification with ServiceWorker');
//               });
//             var notify = new Notification('Hi there!', {
//                 body: 'You left ur shoping',
//                 icon: 'https://www.urbanwood.in/images/icon.svg',
//             });
//         } else {
//             // request permission from user
//             Notification.requestPermission().then(function (p) {
//                 if (p === 'granted') {
//                     // show notification here
//                     navigator.serviceWorker.ready.then(function(registration) {
//                         registration.showNotification('Notification with ServiceWorker');
//                       });
//                     var notify = new Notification('Hi there!', {
//                         body: 'You left ur shoping',
//                         icon: 'https://www.urbanwood.in/images/icon.svg',
//                     });
//                 } else {
//                     console.log('User blocked notifications.');
//                 }
//             }).catch(function (err) {
//                 console.error(err);
//             });
//         }
//     }
// }

// setIdleTimeout(5000, function() {
//     // document.body.innerText = "Where did you go?";
//     notifyMe();
// }, function() {
//     '';
// });



// function setIdleTimeout(millis, onIdle, onUnidle) {
//   var timeout = 0;
//   startTimer();

//   function startTimer() {
//     timeout = setTimeout(onExpires, millis);
//     document.addEventListener("mousemove", onActivity);
//     document.addEventListener("keydown", onActivity);
//     document.addEventListener("touchstart", onActivity);
//   }

//   function onExpires() {
//     timeout = 0;
//     onIdle();
//   }

//   function onActivity() {
//     if (timeout) clearTimeout(timeout);
//     else onUnidle();
//     //since the mouse is moving, we turn off our event hooks for 1 second
//     document.removeEventListener("mousemove", onActivity);
//     document.removeEventListener("keydown", onActivity);
//     document.removeEventListener("touchstart", onActivity);
//     setTimeout(startTimer, 1000);
//   }
// }