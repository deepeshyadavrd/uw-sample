
<html lang="en"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="./assets/holi.png">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans&amp;display=swap" rel="stylesheet">
    <title>Holi Splash</title>
    <!-- <link href="./style.css" rel="stylesheet" type="text/css"> -->
    <style>body {
  margin: 0px;
  height: 100vh;
  font-family: "Josefin Sans", sans-serif;
}

canvas {
  background-color: transparent;
  position: absolute;
}

.abs {
  position: absolute;
  z-index: 1;
  width: 100%;
  margin-top: 200px;
  background-color: transparent;
}

.rel {
  display: flex;
  flex-direction: column;
}

#holi-img {
  text-align: center;
  width: 80px;
  margin: 0px auto 0px auto;
  cursor: pointer;
}

h1 {
  text-align: center;
}

.holi-clean-img {
  position: absolute;
  height: 40px;
  width: 35px;
  margin-left: 48%;
  cursor: pointer;
  display: none;
  z-index: 5;
}

.holi-clean-div {
}
</style>
    <script>
      function initHoli(canvas, addColors, removeColors) {
    const ctx = canvas.getContext("2d");
    addColors.addEventListener("click", () => {
        bindToCanvas(canvas, ctx);
        canvas.click();
        addColors.style.display = "none";
        removeColors.style.display = "block";
        clearScreen(canvas, ctx, addColors, removeColors)
    })
}

function clearScreen(canvas, ctx, addColors, removeColors) {
    removeColors.addEventListener("click", e => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        addColors.style.display = "block";
        removeColors.style.display = "none";
        canvas.removeEventListener("click", e => paintToCanvas(e, ctx))
    })
}

function bindToCanvas(canvas, ctx) {
    canvas.addEventListener("click", e => paintToCanvas(e, ctx))
}

function paintToCanvas(e, ctx) {
    const colors = ["#AF1490", "#FF9900", "#599F00", "#3E43E5", "#E20000", "#6583C6", "#D95EB4", "#F15A50", "#FD9E1B", "#F9D73A", "#FC395D", "#FECC3B", "#438CFF", "#71CA97", "#FF3C38", "#FF9400", "#FFEC00", "#00EE5B", "#B6004C"];
    const colorIndex = Math.floor(Math.random() * 18);
    const darkColor = LightenDarkenColor(colorIndex, -50);
    ctx.beginPath();
    const x = e.clientX;
    const y = e.clientY;
    for (let i = 0; i < 1000; i++) {
        let re = Math.floor(Math.random() * 2) + 1;
        let randX = Math.floor(Math.random() * (i / 10) * 1) + 1;
        let randY = Math.floor(Math.random() * (i / 10) * 1) + 1;
        let radius = Math.floor(Math.random() * re) + 1;
        let randiusX = randX + (Math.floor(Math.random() * 25) + 1) * Math.cos(randX);
        let randiusY = randY + (Math.floor(Math.random() * 25) + 1) * Math.cos(randY);
        ctx.beginPath();
        ctx.arc(x + randiusX, y + randiusY, re, 0, Math.PI * 2);
        ctx.fillStyle = colors[colorIndex];
        ctx.fill();
        ctx.closePath();
        ctx.beginPath();
        ctx.arc(x + randX, y + randY, radius, 0, Math.PI * 2);
        ctx.fillStyle = colors[colorIndex];
        ctx.fill();
        ctx.closePath();
        ctx.beginPath();
        ctx.arc(x - randX / 2, y + randY / 2, radius / 2, 0, Math.PI * 2);
        ctx.fillStyle = darkColor;
        ctx.fill();
        ctx.closePath();
        ctx.beginPath();
        ctx.arc(x + randX / 2, y - randY / 2, radius / 2, 0, Math.PI * 2);
        ctx.fillStyle = darkColor;
        ctx.fill();
        ctx.closePath();
        ctx.beginPath();
        ctx.arc(x - randX, y - randY, radius, 0, Math.PI * 2);
        ctx.fillStyle = colors[colorIndex];
        ctx.fill();
        ctx.closePath()
    }
}

function LightenDarkenColor(col, amt) {
    var usePound = !1;
    if (col[0] === "#") {
        col = col.slice(1);
        usePound = !0
    }
    var num = parseInt(col, 16);
    var r = (num >> 16) + amt;
    if (r > 255) r = 255;
    else if (r < 0) r = 0;
    var b = ((num >> 8) & 0x00ff) + amt;
    if (b > 255) b = 255;
    else if (b < 0) b = 0;
    var g = (num & 0x0000ff) + amt;
    if (g > 255) g = 255;
    else if (g < 0) g = 0;
    return (usePound ? "#" : "") + (g | (b << 8) | (r << 16)).toString(16)
}
    </script>
  </head>
  <body data-new-gr-c-s-check-loaded="14.1162.0" data-gr-ext-installed="">
    <div class="holi-clean-div">
      <img class="holi-clean-img" id="holi-clean" src="./assets/clean.png" alt="holi clean icon" style="display: none;">
    </div>
    <div class="abs" id="holi-div" style="display: block;">
      <div class="rel">
        <img id="holi-img" src="./assets/holi.png" alt="holi image icon">
        <h1>Happy Holi From India</h1>
      </div>
    </div>
    <canvas id="myCanvas" width="1920" height="953"> </canvas>
  
  <!-- <script src="./holi.min.js" type="text/javascript"></script> -->
  <script>
    document.addEventListener("DOMContentLoaded", ()=>{
    const t = document.getElementById("myCanvas")
      , e = document.getElementById("holi-img")
      , l = document.getElementById("holi-div")
      , a = document.getElementById("holi-clean")
      , n = t.getContext("2d");
      console.log();
    function o(t) {
        const e = ["#AF1490", "#FF9900", "#599F00", "#3E43E5", "#E20000", "#6583C6", "#D95EB4", "#F15A50", "#FD9E1B", "#F9D73A", "#FC395D", "#FECC3B", "#438CFF", "#71CA97", "#FF3C38", "#FF9400", "#FFEC00", "#00EE5B", "#B6004C"]
          , l = Math.floor(18 * Math.random())
          , a = function(t, e) {
            var l = !1;
            "#" === t[0] && (t = t.slice(1),
            l = !0);
            var a = parseInt(t, 16)
              , n = (a >> 16) + e;
            n > 255 ? n = 255 : n < 0 && (n = 0);
            var o = (a >> 8 & 255) + e;
            o > 255 ? o = 255 : o < 0 && (o = 0);
            var i = (255 & a) + e;
            i > 255 ? i = 255 : i < 0 && (i = 0);
            return (l ? "#" : "") + (i | o << 8 | n << 16).toString(16)
        }(l, -50);
        n.beginPath();
        const o = t.clientX
          , i = t.clientY;
        for (let t = 0; t < 1e3; t++) {
            let c = Math.floor(2 * Math.random()) + 1
              , h = Math.floor(Math.random() * (t / 10) * 1) + 1
              , d = Math.floor(Math.random() * (t / 10) * 1) + 1
              , r = Math.floor(Math.random() * c) + 1
              , s = h + (Math.floor(25 * Math.random()) + 1) * Math.cos(h)
              , M = d + (Math.floor(25 * Math.random()) + 1) * Math.cos(d);
            n.beginPath(),
            n.arc(o + s, i + M, c, 0, 2 * Math.PI),
            n.fillStyle = e[l],
            n.fill(),
            n.closePath(),
            n.beginPath(),
            n.arc(o + h, i + d, r, 0, 2 * Math.PI),
            n.fillStyle = e[l],
            n.fill(),
            n.closePath(),
            n.beginPath(),
            n.arc(o - h / 2, i + d / 2, r / 2, 0, 2 * Math.PI),
            n.fillStyle = a,
            n.fill(),
            n.closePath(),
            n.beginPath(),
            n.arc(o + h / 2, i - d / 2, r / 2, 0, 2 * Math.PI),
            n.fillStyle = a,
            n.fill(),
            n.closePath(),
            n.beginPath(),
            n.arc(o - h, i - d, r, 0, 2 * Math.PI),
            n.fillStyle = e[l],
            n.fill(),
            n.closePath()
        }
    }
    e.addEventListener("click", ()=>{
        t.width = document.body.clientWidth,
        t.height = document.body.clientHeight,
        t.addEventListener("click", o),
        t.click(),
        l.style.display = "none",
        a.style.display = "block",
        a.addEventListener("click", ()=>{
            n.clearRect(0, 0, t.width, t.height),
            l.style.display = "block",
            a.style.display = "none",
            t.removeEventListener("click", o)
        }
        )
    }
    )
}
);
    </script>
<!-- <script>
   const canvas = document.getElementById('myCanvas')
  const triggerElement = document.getElementById('holi-img')
  const resetElement = document.getElementById('holi-div')

  initHoli(canvas, triggerElement, resetElement)
</script> -->
</body></html>